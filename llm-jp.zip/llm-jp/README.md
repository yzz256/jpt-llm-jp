# The whole process

```bash
# Clone repository
git clone https://github.com/llm-jp/llm-jp-sft.git ./llm-jp-sft

# Download dataset
wget https://raw.githubusercontent.com/kunishou/databricks-dolly-15k-ja/main/databricks-dolly-15k-ja.json -P llm-jp-sft/data/

# Convert format
python data_convert.py

# Copy config
cp accelerate_config_a10g.yaml llm-jp-sft/configs/accelerate_config_a10g.yaml

# Download model
git clone https://huggingface.co/llm-jp/llm-jp-1.3b-v1.0 ./llm-jp-sft/model/llm-jp-1.3b-v1.0

# Fine-tuning
cd llm-jp-sft
pip install -r requirements.in
accelerate launch --config_file configs/accelerate_config_a10g.yaml \
train.py \
--num_train_epochs 5 \
--per_device_train_batch_size 1 \
--gradient_accumulation_steps 8 \
--learning_rate 1e-4 \
--warmup_ratio 0.1 \
--lr_scheduler cosine \
--bf16 \
--max_seq_length 2048 \
--data_files data/databricks-dolly-15k-ja.jsonl \
--use_peft \
--model_name_or_path model/llm-jp-1.3b-v1.0 \
--output_dir results/llm-jp-1.3b-instruct-lora-dolly-v1.0
```
