import json

# Original data
json_data = []
with open('./llm-jp-sft/data/databricks-dolly-15k-ja.json','r',encoding='utf8')as fp:
    json_data = json.load(fp)

# Convert to the desired format
converted_data = []
for entry in json_data:
    texts = entry['input'].strip()
    texts = texts if texts else "以下の質問に答えなさい。"
    texts = "以下の質問に答えなさい。"
    text = f"### 指示：{texts} ### 質問：{entry['instruction']} ### 回答：{entry['output']}"
    converted_data.append({"text": text})

# Save as a .jsonl file
with open('./llm-jp-sft/data/databricks-dolly-15k-ja.jsonl', 'w') as f:
    for entry in converted_data:
        json.dump(entry, f, ensure_ascii=False)
        f.write('\n')